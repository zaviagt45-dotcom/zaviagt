"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Navigation from "@/components/Navigation"
import Footer from "@/components/Footer"
import { CheckCircle2, MapPin, Clock, Users, Star, Calendar, Utensils, Home } from "lucide-react"

export default function ExperienciaPremiumPage() {
  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center">
        <div className="absolute inset-0">
          <img
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/image-1764213632116.png?width=8000&height=8000&resize=contain&quality=100"
            alt="Escape Total 503"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70"></div>
        </div>
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-center mb-4">
            <Star className="h-6 w-6 text-[#ff0066] fill-current drop-shadow-lg" />
            <Star className="h-6 w-6 text-[#ff0066] fill-current drop-shadow-lg" />
            <Star className="h-6 w-6 text-[#ff0066] fill-current drop-shadow-lg" />
            <Star className="h-6 w-6 text-[#ff0066] fill-current drop-shadow-lg" />
            <Star className="h-6 w-6 text-[#ff0066] fill-current drop-shadow-lg" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]">
            Paquete Escape Premium
          </h1>
          <p className="text-xl text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
            3 días y 3 noches explorando El Salvador
          </p>
        </div>
      </section>

      {/* Quick Info */}
      <section className="py-8 px-4 bg-white border-b">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <Clock className="h-8 w-8 mx-auto mb-2 text-[#ff0066]" />
            <p className="font-semibold">3 días / 3 noches</p>
          </div>
          <div className="text-center">
            <Users className="h-8 w-8 mx-auto mb-2 text-[#ff0066]" />
            <p className="font-semibold">Grupo de 9 personas</p>
          </div>
          <div className="text-center">
            <MapPin className="h-8 w-8 mx-auto mb-2 text-[#ff0066]" />
            <p className="font-semibold">Lugares Turísticos</p>
          </div>
          <div className="text-center">
            <Utensils className="h-8 w-8 mx-auto mb-2 text-[#ff0066]" />
            <p className="font-semibold">1 cena incluida</p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4 max-w-7xl mx-auto">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Descripción del Paquete</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed mb-4">
                Descubre El Salvador con el mejor paquete que te espera durante todo el fin de semana, perfecto para visitar aún más experiencias y que estamos seguros que no podrás olvidar sin dejar atrás la gastronomía, lugares turísticos y mucho más por visitar.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Este paquete incluye transporte cómodo, hospedaje en Airbnb, y una deliciosa cena típica. Es ideal para familias, grupos de amigos, o viajeros que quieren explorar lo mejor de El Salvador en un fin de semana inolvidable.
              </p>
            </CardContent>
          </Card>

          {/* Itinerary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Calendar className="h-6 w-6 text-[#ff0066]" />
                Itinerario
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Punto de Partida */}
                <div className="bg-[#f5e6d3] p-4 rounded-lg border-l-4 border-[#ff0066]">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-6 w-6 text-[#ff0066] flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-lg mb-1">Punto de Partida</h3>
                      <p className="text-gray-700">Casa Abril 15 calle 11-63 zona 1 Ciudad de Guatemala</p>
                    </div>
                  </div>
                </div>

                <div className="border-l-4 border-[#ff0066] pl-4">
                  <h3 className="font-bold text-lg mb-2">Día 1: Viernes - San Salvador</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• <strong>Salida:</strong> 5:00 AM</li>
                    <li>• <strong>Llegada:</strong> 10:30 AM</li>
                    <li>• San Salvador Full Day</li>
                    <li>• Recorrido por el centro histórico</li>
                    <li>• Visita al área comercial</li>
                    <li>• <strong>Cena típica tradicional incluida</strong></li>
                    <li>• Hospedaje en Airbnb</li>
                  </ul>
                </div>

                <div className="border-l-4 border-[#ff0066] pl-4">
                  <h3 className="font-bold text-lg mb-2">Día 2: Sábado - Sol y Playa</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• Sol y playa</li>
                    <li>• Estadía en Costa del Sol</li>
                    <li>• Visita a Sunset Park</li>
                    <li>• Cena a orilla del mar en Puerto La Libertad (no incluida)</li>
                    <li>• Hospedaje en Airbnb</li>
                  </ul>
                </div>

                <div className="border-l-4 border-[#ff0066] pl-4">
                  <h3 className="font-bold text-lg mb-2">Día 3: Domingo - Naturaleza y Miradores</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• El Camino Verde</li>
                    <li>• Balneario Natural Los Chorros</li>
                    <li>• Parque Balboa</li>
                    <li>• Mirador Puerta del Diablo</li>
                    <li>• Hospedaje en Airbnb</li>
                  </ul>
                </div>

                <div className="border-l-4 border-[#ff0066] pl-4">
                  <h3 className="font-bold text-lg mb-2">Día 4: Lunes - Regreso</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• <strong>Regreso:</strong> 5:00 AM</li>
                    <li>• Llegada a Guatemala, Ciudad</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* What's Included */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Incluye</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Transporte en bus</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">3 noches de hospedaje en Airbnb</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Cena típica tradicional buffet ilimitado (Día 1)</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Guía durante traslados</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Hidratación ilimitada</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Servicio de toallas</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Servicio de palapas</span>
                </div>
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-[#ff0066] mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Acceso a playas y piscinas</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* What's NOT Included */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">No Incluye</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-gray-700">
                <p>• Alimentación</p>
                <p>• Pago único por ingreso para extranjeros de: $5 más presentación de pasaporte</p>
              </div>
            </CardContent>
          </Card>

          {/* Contact CTA */}
          <Card className="border-2 border-[#ff0066]">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">¿Interesado en este paquete?</h3>
              <p className="text-gray-700 mb-6">
                Contáctanos para más información sobre fechas disponibles, precios y reservaciones
              </p>
              <Link href="/contacto">
                <Button className="bg-[#ff0066] hover:bg-[#cc0052] text-white text-lg py-6 px-8">
                  Contactar Ahora
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  )
}