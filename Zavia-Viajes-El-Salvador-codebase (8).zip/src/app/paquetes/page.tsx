"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Navigation from "@/components/Navigation"
import Footer from "@/components/Footer"
import { MapPin, Clock, Users, Star, CheckCircle2, Sparkles } from "lucide-react"

export default function PaquetesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-[#ffe0d0]/20 to-white">
      <Navigation />

      {/* Hero Section - Solid Color with Modern Design */}
      <section className="relative bg-black py-20">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmFhMDAiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE4YzAtOS45NC04LjA2LTE4LTE4LTE4IDAtOS45NCA4LjA2LTE4IDE4LTE4czE4IDguMDYgMTggMTgtOC4wNiAxOC0xOCAxOGMwIDkuOTQtOC4wNiAxOC0xOCAxOHMtMTgtOC4wNi0xOC0xOCAxOC04LjA2IDE4LTE4eiIvPjwvZz48L2c+PC9zdmc+')] opacity-50"></div>
        
        <div className="relative z-10 text-center max-w-5xl mx-auto px-4">
          <div className="inline-flex items-center gap-2 px-5 py-2 bg-[#ffaa00] rounded-full mb-6">
            <Sparkles className="h-5 w-5 text-black" />
            <span className="text-sm font-bold text-black">EXPLORA EL SALVADOR</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-black mb-6 text-white leading-tight">
            Nuestros <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ffaa00] to-[#ff0066]">Paquetes</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto font-light">
            Descubre experiencias únicas diseñadas para que vivas lo mejor de El Salvador
          </p>
        </div>
      </section>

      {/* Packages Section - Modern Card Design */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Package 1 - Ruta del Sol */}
          <div className="group relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#ffd700] to-[#ffaa00] rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-300"></div>
            
            <Card className="relative bg-white rounded-3xl border-0 shadow-2xl overflow-hidden hover:shadow-[#ffaa00]/20 transition-all duration-300">
              {/* Image with Overlay */}
              <div className="relative h-72 overflow-hidden">
                <img
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/image-1764213018436.png?width=8000&height=8000&resize=contain"
                  alt="Ruta del Sol"
                  className="w-full h-full object-cover object-[center_65%] group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                
                {/* Badge */}
                <div className="absolute top-6 left-6">
                  <span className="inline-flex items-center gap-2 px-4 py-2 bg-[#ffd700] rounded-full shadow-lg">
                    <span className="text-sm font-black text-black">ECONÓMICO</span>
                  </span>
                </div>
                
                {/* Title & Rating */}
                <div className="absolute bottom-6 left-6 right-6">
                  <h3 className="text-3xl font-black text-white mb-2">paquete Ruta del Sol</h3>
                  <div className="flex items-center gap-1">
                    {[...Array(3)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-[#ffd700] fill-[#ffd700]" />
                    ))}
                    {[...Array(2)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-gray-400" />
                    ))}
                  </div>
                </div>
              </div>

              <CardContent className="p-8">
                {/* Features List */}
                <div className="space-y-4 mb-8">
                  {[
                    "3 días / 2 noches",
                    "Transporte en bus",
                    "Visitas a playas y pueblos coloniales",
                    "Hospedaje estándar",
                    "Desayunos incluidos"
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="mt-1 rounded-full bg-[#ffd700]/10 p-1">
                        <CheckCircle2 className="h-5 w-5 text-[#ffd700]" />
                      </div>
                      <span className="text-gray-700 font-medium">{item}</span>
                    </div>
                  ))}
                </div>

                {/* Info Bar */}
                <div className="flex items-center justify-around py-4 px-6 bg-[#ffe0d0] rounded-2xl mb-8">
                  <div className="text-center">
                    <Clock className="h-5 w-5 text-[#ffaa00] mx-auto mb-1" />
                    <span className="text-sm font-bold text-gray-700">3 días</span>
                  </div>
                  <div className="h-8 w-px bg-gray-300"></div>
                  <div className="text-center">
                    <Users className="h-5 w-5 text-[#ffaa00] mx-auto mb-1" />
                    <span className="text-sm font-bold text-gray-700">20-30</span>
                  </div>
                  <div className="h-8 w-px bg-gray-300"></div>
                  <div className="text-center">
                    <MapPin className="h-5 w-5 text-[#ffaa00] mx-auto mb-1" />
                    <span className="text-sm font-bold text-gray-700">5 destinos</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-4">
                  <Link href="/paquetes/aventura-economica" className="block">
                    <Button className="w-full bg-[#ffd700] hover:bg-[#e6c200] text-black font-bold py-6 rounded-xl shadow-lg hover:shadow-[#ffd700]/50 transition-all">
                      Ver Detalles
                    </Button>
                  </Link>
                  <Link href="/contacto" className="block">
                    <Button variant="outline" className="w-full border-2 border-[#ffd700] text-black hover:bg-[#ffd700] hover:text-black font-bold py-6 rounded-xl transition-all">
                      Contactar
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Package 2 - Escape Total 503 */}
          <div className="group relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#ff0066] to-[#ff0099] rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-300"></div>
            
            <Card className="relative bg-white rounded-3xl border-0 shadow-2xl overflow-hidden hover:shadow-[#ff0066]/20 transition-all duration-300">
              {/* Image with Overlay */}
              <div className="relative h-72 overflow-hidden">
                <img
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/image-1764213632116.png?width=8000&height=8000&resize=contain&quality=100"
                  alt="Escape Total 503"
                  className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                
                {/* Badge */}
                <div className="absolute top-6 left-6">
                  <span className="inline-flex items-center gap-2 px-4 py-2 bg-[#ff0066] rounded-full shadow-lg">
                    <Sparkles className="h-4 w-4 text-white" />
                    <span className="text-sm font-black text-white">PREMIUM</span>
                  </span>
                </div>
                
                {/* Title & Rating */}
                <div className="absolute bottom-6 left-6 right-6">
                  <h3 className="text-3xl font-black text-white mb-2">Paquete Escape Premium</h3>
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-[#ff0066] fill-[#ff0066]" />
                    ))}
                  </div>
                </div>
              </div>

              <CardContent className="p-8">
                {/* Features List */}
                <div className="space-y-4 mb-8">
                  {[
                    "3 días / 3 noches",
                    "Transporte en bus",
                    "3 noches de hospedaje en Airbnb",
                    "1 cena típica incluida",
                    "Hidratación ilimitada",
                    "Guía turístico"
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="mt-1 rounded-full bg-[#ff0066]/10 p-1">
                        <CheckCircle2 className="h-5 w-5 text-[#ff0066]" />
                      </div>
                      <span className="text-gray-700 font-medium">{item}</span>
                    </div>
                  ))}
                </div>

                {/* Info Bar */}
                <div className="flex items-center justify-around py-4 px-6 bg-[#ff0066]/5 rounded-2xl mb-8">
                  <div className="text-center">
                    <Clock className="h-5 w-5 text-[#ff0066] mx-auto mb-1" />
                    <span className="text-sm font-bold text-gray-700">3 días</span>
                  </div>
                  <div className="h-8 w-px bg-gray-300"></div>
                  <div className="text-center">
                    <Users className="h-5 w-5 text-[#ff0066] mx-auto mb-1" />
                    <span className="text-sm font-bold text-gray-700">9 personas</span>
                  </div>
                  <div className="h-8 w-px bg-gray-300"></div>
                  <div className="text-center">
                    <MapPin className="h-5 w-5 text-[#ff0066] mx-auto mb-1" />
                    <span className="text-sm font-bold text-gray-700">Turístico</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-4">
                  <Link href="/paquetes/experiencia-premium" className="block">
                    <Button className="w-full bg-[#ff0066] hover:bg-[#cc0052] text-white font-bold py-6 rounded-xl shadow-lg hover:shadow-[#ff0066]/50 transition-all">
                      Ver Detalles
                    </Button>
                  </Link>
                  <Link href="/contacto" className="block">
                    <Button variant="outline" className="w-full border-2 border-[#ff0066] text-black hover:bg-[#ff0066] hover:text-white font-bold py-6 rounded-xl transition-all">
                      Contactar
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}